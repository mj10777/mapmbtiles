# Just a placeholder

from main import MainFrame
from config import version
